PROJET DE LA MINI DÉMONSTRATION

La vidéo montre les captures horodatées de l’interface réelle du laboratoire,
avec un run Ollama réussi : 2026-11-12T15-15-13-789Z.
Aucun audio. Annotations françaises, sans accélération.
Les coupes retirent seulement les intervalles entre les sections de navigation.
Les sources se trouvent dans assets/. Le montage est décrit par timeline.json.

Reproduction :
python3 -m pip install -r requirements-video.txt
python3 render.py

Le script utilise Arial du Mac. Sur un autre système, placer une police TTF
librement utilisable sous le nom Arial.ttf à côté de render.py.
La sortie est ../arms-demo.mp4. Archiver une ancienne sortie avant de relancer.
Les images de la banque, les données personnelles et les systèmes réels
ne sont jamais employés : l’interface et les données appartiennent au lab fictif.
