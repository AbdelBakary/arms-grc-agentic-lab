"""Render the captured demo at its original speed. pip install pillow imageio-ffmpeg"""
from pathlib import Path
import json, shutil, subprocess, textwrap, math, bisect
from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'timeline.json').read_text())
BUILD=ROOT/'build'
BUILD.mkdir(exist_ok=True)
font_regular=Path('/System/Library/Fonts/Supplemental/Arial.ttf')
font_bold=Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
# On other systems supply any TTF under these names next to this script.
if not font_regular.exists(): font_regular=ROOT/'Arial.ttf'
if not font_bold.exists(): font_bold=font_regular
font=lambda n,b=False:ImageFont.truetype(str(font_bold if b else font_regular),n)
W,H=720,1280
concat=[]
events=[]
cue=[]
for shot in meta['shots']:
    frames=shot['frames']
    cue.append(f"{shot['sequenceStart']:.3f}–{shot['sequenceEnd']:.3f} s : {shot['title']} (1.0×)")
    for i,frame in enumerate(frames):
        screenshot=Image.open(ROOT/frame['asset']).convert('RGB')
        canvas=Image.new('RGB',(W,H),'#0b1324')
        draw=ImageDraw.Draw(canvas)
        draw.text((28,22),'ARMS · RED TEAM GRC',(117,219,197),font=font(20,True))
        draw.text((28,56),shot['title'],'#ffffff',font=font(32,True))
        available=(W,1030)
        screenshot.thumbnail(available,Image.Resampling.LANCZOS)
        canvas.paste(screenshot,((W-screenshot.width)//2,122+(1030-screenshot.height)//2))
        for j,line in enumerate(textwrap.wrap(shot['caption'],width=54)):
            draw.text((28,1168+j*27),line,'#e9eef6',font=font(23))
        draw.text((28,1250),'Ollama local · données synthétiques · sans accélération','#aebfd1',font=font(18))
        out=BUILD/(shot['id']+f'-{i:04d}.png')
        canvas.save(out)
        events.append((frame['sequenceTime'],out))
        end=frames[i+1]['sourceTime'] if i+1<len(frames) else shot['sourceOut']
        duration=end-frame['sourceTime']
        assert duration>0
        concat.extend([f"file '{out.name}'",f'duration {duration:.6f}'])
(ROOT/'cues.txt').write_text('\n'.join(cue)+'\n')
output=ROOT.parent/'arms-demo.mp4'
assert not output.exists(), 'Choose a new output name or archive the previous draft first.'
fps=meta['output']['fps']
cmd=[imageio_ffmpeg.get_ffmpeg_exe(),'-n','-v','warning','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(fps),'-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','22','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart',str(output)]
with (ROOT/'render.log').open('w') as log:
    process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=log,stderr=log)
    times=[x[0] for x in events]
    previous=None
    pixels=None
    for frame_index in range(math.ceil(meta['durationSeconds']*fps)):
        source=events[max(0,bisect.bisect_right(times,frame_index/fps)-1)][1]
        if source!=previous:
            pixels=Image.open(source).convert('RGB').tobytes()
            previous=source
        process.stdin.write(pixels)
    process.stdin.close()
    if process.wait()!=0: raise RuntimeError('FFmpeg export failed; inspect render.log')
print(output,output.stat().st_size)
